-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th2 19, 2023 lúc 08:40 AM
-- Phiên bản máy phục vụ: 10.4.24-MariaDB
-- Phiên bản PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `ptpmmnm_cafe`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_tiet_hoa_don`
--

CREATE TABLE `chi_tiet_hoa_don` (
  `MaHD` varchar(15) NOT NULL,
  `MaSP` varchar(15) NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `DonGia` int(11) NOT NULL,
  `ThanhTien` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `chi_tiet_hoa_don`
--

INSERT INTO `chi_tiet_hoa_don` (`MaHD`, `MaSP`, `SoLuong`, `DonGia`, `ThanhTien`, `updated_at`) VALUES
('HD1', '5000628', 2, 50000, 100000, '2022-11-22 20:51:42'),
('HD2', '5000628', 1, 50000, 1, '2022-11-23 04:13:03'),
('HD1', '5000097', 1, 30000, 30000, '2022-11-23 04:13:22'),
('HD3', 'AMINO01', 4, 40000, 160000, '2022-11-23 04:13:39'),
('HD4', '5000628', 3, 198000, 594000, '2022-11-23 07:00:51'),
('HD4', 'CULI', 10, 156000, 1560000, '2022-11-23 07:00:51'),
('HD5', '5000628', 2, 198000, 396000, '2022-11-23 08:19:25');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_tiet_phieu_nhap`
--

CREATE TABLE `chi_tiet_phieu_nhap` (
  `MaPNH` varchar(15) NOT NULL,
  `MaSP` varchar(15) NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `DonGia` int(11) NOT NULL,
  `ThanhTien` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `chi_tiet_phieu_nhap`
--

INSERT INTO `chi_tiet_phieu_nhap` (`MaPNH`, `MaSP`, `SoLuong`, `DonGia`, `ThanhTien`, `updated_at`) VALUES
('PNH1', 'CULI', 2, 130000, 260000, '2022-11-22 18:10:03'),
('PNH1', 'MOKA01', 5, 140000, 700000, '2022-11-22 06:09:44');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_tiet_quyen`
--

CREATE TABLE `chi_tiet_quyen` (
  `MaQuyen` varchar(15) NOT NULL,
  `MaChucNang` varchar(15) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `chi_tiet_quyen`
--

INSERT INTO `chi_tiet_quyen` (`MaQuyen`, `MaChucNang`, `updated_at`) VALUES
('AD', 'DASH', '2022-11-23 03:08:23'),
('AD', 'DGSP', '2022-11-23 03:08:23'),
('AD', 'HD', '2022-11-23 03:08:23'),
('AD', 'KH', '2022-11-23 03:08:23'),
('AD', 'LSP', '2022-11-23 03:08:23'),
('AD', 'NCC', '2022-11-23 03:08:23'),
('AD', 'NV', '2022-11-23 03:08:23'),
('AD', 'PNH', '2022-11-23 03:08:23'),
('AD', 'QTK', '2022-11-23 03:08:23'),
('AD', 'SP', '2022-11-23 03:08:23'),
('AD', 'TK', '2022-11-23 03:08:23'),
('NVBH', 'HD', '2022-11-23 02:09:36'),
('NVBH', 'KH', '2022-11-23 02:09:40'),
('NVBH', 'PNH', '2022-11-23 02:09:45'),
('NVTK', 'HD', '2022-11-23 02:22:40'),
('NVTK', 'DGSP', '2022-11-23 02:32:08');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chuc_nang`
--

CREATE TABLE `chuc_nang` (
  `MaChucNang` varchar(15) NOT NULL,
  `TenChucNang` varchar(100) NOT NULL,
  `Icon` varchar(300) NOT NULL,
  `Link` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `chuc_nang`
--

INSERT INTO `chuc_nang` (`MaChucNang`, `TenChucNang`, `Icon`, `Link`) VALUES
('DASH', 'Dashboard', '<DashboardIcon className=\'icon\' />', 'home'),
('DGSP', 'Đánh giá', '<ThumbsUpDownIcon className=\'icon\' />', 'votes'),
('HD', 'Hóa đơn', '<ReceiptLongIcon className=\'icon\' />', 'bill'),
('KH', 'Khách hàng', '<GroupsIcon className=\'icon\' />', 'customer'),
('LSP', 'Loại sản phẩm', '<CategoryIcon className=\'icon\' />', 'category'),
('NCC', 'Nhà cung cấp', '<LocalShippingIcon className=\'icon\' />', 'provider'),
('NV', 'Nhân viên', '<ContactEmergencyIcon className=\'icon\' />', 'staff'),
('PNH', 'Phiếu nhập hàng', '<FactCheckIcon className=\'icon\' />', 'imports'),
('QTK', 'Quyền tài khoản', '<PsychologyIcon className=\'icon\' />', 'functions'),
('SP', 'Sản phẩm', '<LocalCafeIcon className=\'icon\' />', 'products'),
('TK', 'Tài khoản', '<RecordVoiceOverIcon className=\'icon\' />', 'accounts');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_gia_san_pham`
--

CREATE TABLE `danh_gia_san_pham` (
  `MaBinhLuan` varchar(50) NOT NULL,
  `MaTK` bigint(20) UNSIGNED NOT NULL,
  `MaSP` varchar(15) NOT NULL,
  `BinhLuan` varchar(500) NOT NULL,
  `SoSao` int(11) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `danh_gia_san_pham`
--

INSERT INTO `danh_gia_san_pham` (`MaBinhLuan`, `MaTK`, `MaSP`, `BinhLuan`, `SoSao`, `TrangThai`, `updated_at`) VALUES
('BLTAIKHOANAD1SP01', 2, 'ARABICA', 'bsdfgsdfvxzcvervzdfzdfzg', 4, 1, '2022-11-23 01:43:32'),
('BLTAIKHOANAD1SP02', 7, 'GU02', 'abc123', 4, 1, '2022-11-23 02:15:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoa_don`
--

CREATE TABLE `hoa_don` (
  `MaHD` varchar(15) NOT NULL,
  `MaNV` varchar(15) NOT NULL,
  `MaKH` varchar(15) NOT NULL,
  `HoKH` varchar(50) NOT NULL,
  `TenKH` varchar(50) NOT NULL,
  `NgaySinh` date NOT NULL,
  `GioiTinh` tinyint(1) NOT NULL,
  `DiaChi` varchar(150) NOT NULL,
  `SoDienThoai` varchar(15) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `NgayLapHD` date NOT NULL,
  `TongTien` int(11) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hoa_don`
--

INSERT INTO `hoa_don` (`MaHD`, `MaNV`, `MaKH`, `HoKH`, `TenKH`, `NgaySinh`, `GioiTinh`, `DiaChi`, `SoDienThoai`, `Email`, `NgayLapHD`, `TongTien`, `TrangThai`, `updated_at`) VALUES
('HD1', 'NV1', 'KH4', 'Trần Văn', 'Xoài', '2002-05-04', 0, '145 Trần Hưng Đạo', '0987654321', 'abc123@gmail.com', '2022-11-10', 200000, 4, '2022-11-22 19:56:14'),
('HD2', 'NV2', 'KH5', 'Nguyễn Văn', 'A', '2002-11-14', 0, '34 Nguyễn Trãi', '0234715689', 'ksadj@gmail.com', '2022-10-04', 300000, 4, '2022-11-18 17:49:34'),
('HD3', 'NV3', 'KH3', 'Nguyễn Thị', 'Nho', '1999-06-20', 1, '23/1 Nguyễn Sơn', '0985674321', 'ksadj@adfwe@gmail.com.com', '2022-08-13', 280000, 4, '2022-11-18 17:49:34'),
('HD4', 'null', 'null', 'abc', 'kksdjfn', '2022-11-16', 0, '23 Nguyễn Trãi', '0123456789', 'abc@gmail.com', '2022-11-23', 2154000, 1, '2022-11-23 07:00:51'),
('HD5', 'null', 'null', 'Nvuyeenx', 'A', '2022-11-03', 0, 'akasbjd', '0123456789', 'abc@gmail.com', '2022-11-23', 396000, 1, '2022-11-23 08:19:25');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khach_hang`
--

CREATE TABLE `khach_hang` (
  `MaKH` varchar(15) NOT NULL,
  `MaTK` bigint(20) UNSIGNED NOT NULL,
  `HoKH` varchar(50) NOT NULL,
  `TenKH` varchar(50) NOT NULL,
  `NgaySinh` date NOT NULL,
  `GioiTinh` tinyint(1) NOT NULL,
  `DiaChi` varchar(150) NOT NULL,
  `SoDienThoai` varchar(15) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `khach_hang`
--

INSERT INTO `khach_hang` (`MaKH`, `MaTK`, `HoKH`, `TenKH`, `NgaySinh`, `GioiTinh`, `DiaChi`, `SoDienThoai`, `Email`, `TrangThai`, `updated_at`) VALUES
('KH2', 1, 'Trần Văn', 'Xoài', '2002-05-04', 0, '145 Trần Hưng Đạo', '0987654321', 'abc123@gmail.com', 1, '0000-00-00 00:00:00'),
('KH3', 1, 'Nguyễn Thị', 'Nho', '1999-06-20', 1, '23/1 Nguyễn Sơn', '0985674321', 'adfwe@gmail.com', 1, '0000-00-00 00:00:00'),
('KH4', 1, 'Phạm Văn', 'Tân', '2001-10-23', 0, '37 Lũy Bán Bích', '0879654321', 'abc456@gmail.com', 1, '0000-00-00 00:00:00'),
('KH5', 1, 'Lê Văn', 'Dũng', '1997-01-12', 0, '56/12 Hồng Bàng', '0987654123', 'xyz567@gmail.com', 1, '0000-00-00 00:00:00'),
('null', 1, 'null', 'null', '2002-11-14', 0, 'null', 'null', 'null', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai_sp`
--

CREATE TABLE `loai_sp` (
  `MaLoaiSP` varchar(15) NOT NULL,
  `TenLoai` varchar(150) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `loai_sp`
--

INSERT INTO `loai_sp` (`MaLoaiSP`, `TenLoai`, `TrangThai`, `updated_at`) VALUES
('COLD', 'Cà phê ủ lạnh', 1, '2022-11-21 03:57:26'),
('ESPRESS', 'Cà phê Espresso', 1, '2022-11-21 03:51:09'),
('NGCHAT', 'Cà phê nguyên chất', 1, '2022-11-21 03:53:29'),
('PHIN', 'Cà phê pha phin', 1, '2022-11-21 03:54:13'),
('ROB', 'Cà phê Robusta', 1, '2022-11-21 03:56:47');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_11_19_171327_add_jwt_token_to_user_table', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `MaNV` varchar(15) NOT NULL,
  `MaTK` bigint(20) UNSIGNED NOT NULL,
  `HoNV` varchar(50) NOT NULL,
  `TenNV` varchar(50) NOT NULL,
  `NgaySinh` date NOT NULL,
  `GioiTinh` tinyint(1) NOT NULL,
  `DiaChi` varchar(150) NOT NULL,
  `SoDienThoai` varchar(15) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Luong` int(11) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nhan_vien`
--

INSERT INTO `nhan_vien` (`MaNV`, `MaTK`, `HoNV`, `TenNV`, `NgaySinh`, `GioiTinh`, `DiaChi`, `SoDienThoai`, `Email`, `Luong`, `TrangThai`, `updated_at`) VALUES
('null', 1, '', '', '0000-00-00', 0, '', '', '', 0, 0, '2022-11-21 05:17:12'),
('NV1', 2, 'Nguyễn Văn', 'Minh Đức', '2001-04-14', 0, '273 An Dương Vương, Q5', '0368708796', 'minhduc140401@gmail.com', 50000000, 1, '2022-11-18 19:11:59'),
('NV2', 1, 'Lê Thị', 'Cẩm Duyên', '2001-08-20', 1, '25 Song Hành', '0123456789', 'Camduyen20012@gmail.com', 3000000, 1, '2022-11-17 18:31:30'),
('NV3', 1, 'Cao Nguyễn Phương', 'Trang', '2001-11-03', 1, '223 Lê Văn Quới', '0123456789', 'trang123@gmail.com', 10000000, 1, '2022-11-18 19:12:33');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nha_cung_cap`
--

CREATE TABLE `nha_cung_cap` (
  `MaNCC` varchar(15) NOT NULL,
  `TenNCC` varchar(150) NOT NULL,
  `DiaChi` varchar(150) NOT NULL,
  `SoDienThoai` varchar(15) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nha_cung_cap`
--

INSERT INTO `nha_cung_cap` (`MaNCC`, `TenNCC`, `DiaChi`, `SoDienThoai`, `TrangThai`, `updated_at`) VALUES
('NCC1', 'Cafe Trung Nguyên', '23 Cao Thắng Q3, TPHCM', '0123456789', 1, '2022-11-18 18:35:52'),
('NCC2', '90S Coffee', '20 Đường số 3, P. Trường Thọ, TP. Thủ Đức, Hồ Chí Minh', '0929899998', 1, '0000-00-00 00:00:00'),
('NCC3', 'Taf Coffee', '2 đường 12, P, Số 12, Khu phố 5, Thủ Đức, Thành phố Hồ Chí Minh', '02837260192', 1, '0000-00-00 00:00:00'),
('NCC4', 'Vua cafe sạch', '52 Đ. số 14, Bình Hưng Hoà A, Bình Tân, Thành phố Hồ Chí Minh', '0937841056', 1, '0000-00-00 00:00:00'),
('NCC5', 'Buôn Mê Coffee', '35/4A Ao Đôi, Bình Trị Đông A, Bình Tân, Thành phố Hồ Chí Minh', '0909555301', 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phieu_nhap_hang`
--

CREATE TABLE `phieu_nhap_hang` (
  `MaPNH` varchar(15) NOT NULL,
  `MaNV` varchar(15) NOT NULL,
  `MaNCC` varchar(15) NOT NULL,
  `NgayNhapHang` date NOT NULL,
  `TongTien` int(11) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `phieu_nhap_hang`
--

INSERT INTO `phieu_nhap_hang` (`MaPNH`, `MaNV`, `MaNCC`, `NgayNhapHang`, `TongTien`, `TrangThai`, `updated_at`) VALUES
('PNH1', 'NV1', 'NCC3', '2022-11-21', 960000, 1, '2022-11-22 18:37:54'),
('PNH2', 'NV1', 'NCC1', '2022-11-22', 0, 1, '2022-11-22 06:43:15'),
('PNH3', 'NV1', 'NCC4', '2022-11-20', 0, 1, '2022-11-22 06:45:57');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `quyen_tai_khoan`
--

CREATE TABLE `quyen_tai_khoan` (
  `MaQuyen` varchar(15) NOT NULL,
  `TenQuyen` varchar(150) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `quyen_tai_khoan`
--

INSERT INTO `quyen_tai_khoan` (`MaQuyen`, `TenQuyen`, `TrangThai`, `updated_at`) VALUES
('AD', 'Admin', 0, '0000-00-00 00:00:00'),
('KH', 'Khách hàng', 0, '0000-00-00 00:00:00'),
('NV', 'Nhân viên', 0, '2022-11-21 05:12:42'),
('NVBH', 'Nhân viên bán hàng', 1, '2022-11-23 02:14:03'),
('NVTK', 'Nhân viên thống kê', 1, '2022-11-23 02:22:34'),
('QL', 'Quản lý', 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `san_pham`
--

CREATE TABLE `san_pham` (
  `MaSP` varchar(15) NOT NULL,
  `MaLoaiSP` varchar(15) NOT NULL,
  `MaNCC` varchar(15) NOT NULL,
  `TenSP` varchar(150) NOT NULL,
  `Hinh` varchar(100) NOT NULL,
  `MoTa` longtext NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `Gia` int(11) NOT NULL,
  `GiaBan` int(11) NOT NULL,
  `TrangThai` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `san_pham`
--

INSERT INTO `san_pham` (`MaSP`, `MaLoaiSP`, `MaNCC`, `TenSP`, `Hinh`, `MoTa`, `SoLuong`, `Gia`, `GiaBan`, `TrangThai`, `updated_at`) VALUES
('5000097', 'NGCHAT', 'NCC1', 'Cà phê Lon lớn Premium Blend - 425gr', 'uploads/product/20221121161205-premium_01.jpg', 'Nhà sản xuất:Trung Nguyên\r\n\r\nThành phần: Cà phê rang xay Premium Blend gồm 4 loại hạt cà phê Arabica, Robusta, Excelsa, Catimor ngon nhất.\r\n\r\nĐặc tính:\r\n\r\nNước pha màu nâu đậm.\r\nMùi thơm đặc trưng, bền, đầm.\r\nVị đậm đà.\r\nHàm lượng Caffeine: ≥ 1 %.\r\nKhối lượng:Lon 425gr.', 20, 120000, 150000, 1, '2022-11-21 04:12:05'),
('5000628', 'NGCHAT', 'NCC1', 'Cà Phê Drip - Chồn (Weasel) hạt số 8 - 250gr', 'uploads/product/20221121160951-weasel_1_1_1.jpg', 'Nhà sản xuất:Trung Nguyên\r\n\r\nThành phần: từ những hạt cà phê Arabica, Robusta, Excelsa.\r\n\r\nĐặc điểm: \r\n\r\nNước pha sánh đậm đà.\r\nHương thơm đặc trưng của cà phê Chồn.\r\nLà một sự cân bằng hoàn hảo giữa hương và vị.\r\nHạn sử dụng:1 năm.', 20, 166000, 198000, 1, '2022-11-21 04:09:51'),
('5000655', 'NGCHAT', 'NCC1', 'Trung Nguyên Legend Cappuccino Mocha bịch 1kg', 'uploads/product/20221121160212-5000655.jpg', '- Bảo quản: trong bao bì kín, nơi khô ráo, thoáng mát', 20, 200000, 240000, 1, '2022-11-21 04:02:12'),
('5000656', 'NGCHAT', 'NCC1', 'Cà phê Passiona hòa tan 4in1 hộp 14 gói 16gr', 'uploads/product/20221121160538-5000656-1.jpg', 'Nhà sản xuất:Trung Nguyên.\r\n\r\nThành phần:Cà phê, sữa, đường, collgen.\r\n\r\nĐặc điểm:Hàm lượng caffein thấp, bổ sung collagen cho da và sắc đẹp của phụ nữ.\r\n\r\nHạn sử dụng:2 năm.\r\n\r\nKhối lượng:Hộp 14 gói x 16gr.', 20, 35000, 50000, 1, '2022-11-21 04:05:38'),
('5000727', 'NGCHAT', 'NCC1', 'Trung Nguyên Legend Success 3', 'uploads/product/20221121160817-5000727.jpg', 'Là loại cà phê siêu hạng có hương vị độc đáo và đầy thử thách. Mùi hương dịu nhẹ nhưng rất đa dạng; Thể chất mạnh nhưng cân bằng, hậu vị ngọt dịu.\r\n\r\nTrọng lượng tịnh: 340g', 20, 187000, 203000, 1, '2022-11-21 04:08:17'),
('AMINO01', 'PHIN', 'NCC5', 'Cà Phê Bột Pha Phin AMINO Signature', 'uploads/product/20221121165611-Ca-phe-Bot-Pha-Phin-Amino-Signature-1200x800.jpg', 'Cà phê bột pha phin Amino Signature là thành quả nghiên cứu sau 7 năm, khao khát làm ra một sản phẩm đặc trưng mang dấu ấn của AMINO. Kết hợp giữa gu cà phê truyền thống, nét ẩm thực rất riêng của Hà Nội và những kiến thức cà phê quốc tế.', 20, 256000, 318000, 1, '2022-11-21 04:56:11'),
('ARABICA', 'ESPRESS', 'NCC3', 'Arabica Washed Espresso', 'uploads/product/20221121162938-Screenshot2022-11-21232851.jpg', 'Hương vị ngọt ngào của caramel kết hợp cùng mùi thơm nhẹ nhàng của chanh vàng sẽ đem đến cho bạn một ly cà phê với tông vị cân bằng, phù hợp với mọi sở thích, vô cùng thoải mái và dễ chịu. Arabica Washed Espresso được Flusso rang ở mức Medium+, chắc chắn sẽ là loại cà phê khiến mọi người hài lòng để thưởng thức hàng ngày.', 20, 60000, 74000, 1, '2022-11-21 04:29:38'),
('CULI', 'ROB', 'NCC3', 'Cà phê nguyên chất Hạt CULI', 'uploads/product/20221121170551-1C6A6754-640x960.jpg', 'Cà Phê Nguyên Chất Hạt CULI sạch 100% đặc biệt có vị đắng đậm đà, mùi hương thơm nhẹ, cafein vừa, chát, hậu vị ngọt.', 22, 130000, 156000, 1, '2022-11-22 18:10:03'),
('FINER01', 'PHIN', 'NCC2', 'Fine Robusta', 'uploads/product/20221121164740-Screenshot2022-11-21234729.jpg', 'Ấn tượng đầu tiên, khi xay hạt bạn sẽ cảm nhận được những mùi hương nồng của gia vị, đặc biệt là quế. Rất nhanh sau đó, những hương ngọt và thơm bắt đầu xuất hiện và khiến bạn liên tưởng tới nho khô. Khi thưởng thức, hương thơm phảng phất của ổi hồng và xoài đi cùng với vị đậm và có một chút hơi ngọt khô giống như lúa mạch trước khi kết thúc bằng hậu vị ngọt ngào của chocolate.', 20, 73000, 100000, 1, '2022-11-21 04:47:40'),
('GU01', 'ROB', 'NCC2', 'Cà phê nguyên chất Hạt GU 1', 'uploads/product/20221121171021-1C6A6750-640x960.jpg', 'Cà Phê Nguyên Chất Hạt GU 1 sạch 100% đặc biệt có vị đắng đậm đà, mùi hương thơm nhẹ, cafein vừa, chát, hậu vị ngọt.', 20, 125000, 159000, 1, '2022-11-21 05:10:21'),
('GU02', 'ROB', 'NCC2', 'Cà phê nguyên chất Hạt GU 2', 'uploads/product/20221121171123-1C6A6742-640x960.jpg', 'Cà Phê Nguyên Chất Hạt GU 2 sạch 100% đặc biệt có vị đắng đậm đà, mùi hương thơm nhẹ, cafein vừa, chát, hậu vị ngọt.', 20, 130000, 179000, 1, '2022-11-21 05:11:23'),
('HONEY01', 'PHIN', 'NCC5', 'Cà Phê Bột Pha Phin Honey Bảo Lộc', 'uploads/product/20221121165745-ca-phe-bot-pha-phin-honey-bao-loc-e1562747677231-768x1152.jpg', 'Cà phê bột pha phin Honey Bảo Lộc là loại cà phê sạch được sản xuất từ những hạt cà phê được lựa chọn từ farm có hệ sinh thái đa dạng, tươi tốt, chăm sóc khoa học và quy trình chế biến đạt đẳng cấp quốc tế.', 20, 118000, 140000, 1, '2022-11-21 04:57:45'),
('HONEY02', 'PHIN', 'NCC5', 'Cà Phê Bột Pha Phin Honey Gia Lai', 'uploads/product/20221121165829-ca-phe-bot-pha-phin-honey-gia-lai-e1562694073172-768x1152.jpg', 'Cà phê bột pha phin Honey Gia Lai là sản phẩm cà phê phin được lựa chọn từ farm có định hướng canh tác hữu cơ trên 5 năm. Sơ chế kiểm soát từng giờ, tối ưu từng chi tiết trong sự phát triển hương vị hạt cà phê. Tạo ra sản phẩm với hương vị phức hợp của hoa quả chín, béo kem, hậu vị ngọt sâu và hương thơm vanilla lan tỏa vòm họng.', 20, 136000, 170000, 1, '2022-11-21 04:58:29'),
('JARAMILLO', 'COLD', 'NCC2', 'Panama Jaramillo Geisha Cherry Mixed', 'uploads/product/20221121162125-Screenshot2022-11-21232108.jpg', 'Ngay từ khi xay hạt, hương thơm ngọt ngào của xoài và chanh dây sẽ chiếm trọn căn phòng của bạn. Đôi lúc, bạn sẽ cảm thấy như mở một chai rượu vang vậy. Ở đoạn đầu khi thưởng thức, những notes hương của các loại trái cây nhiệt đới xuất hiện vô cùng mạnh mẽ, đặc biệt là mùi thơm của quả dứa. Sau đó, hương vị sẽ bắt đầu cân bằng trở lại với sự xuất hiện của nho, dâu tây và đào, vô cùng ngọt ngào và mượt mà trước khi kết thúc với một hậu vị đậm mùi rượu mận và cam bergamot.', 20, 370000, 410000, 1, '2022-11-21 04:21:25'),
('KINGESPRESS', 'ESPRESS', 'NCC4', 'King Coffee Cà Phê Hòa Tan Espresso - Hộp 15 Gói', 'uploads/product/Screenshot2022-11-22002230.jpg', 'KING COFFEE HÒA TAN ESPRESSO: được chế tác từ những hạt cà phê Arabica hảo hạng của vùng đất cà phê trứ danh Việt Nam, kết hợp với bí quyết phương Đông và công nghệ bậc nhất từ châu Âu, đem đến một hương vị đậm đà, mạnh mẽ như một ly Espresso Ý mới pha! Hãy trải nghiệm vị ngon hoàn hảo King Coffee Espresso đến từ vùng nguyên liệu cà phê ngon nhất thế giới!', 20, 110000, 145000, 1, '2022-11-21 04:39:02'),
('LAMANT', 'ESPRESS', 'NCC4', 'Cà phê hòa tan đen Espresso - L\'amant Café Espresso instant coffee', 'uploads/product/20221121163300-Screenshot2022-11-21233200.jpg', 'Với những đặc tính lý tưởng của hạt cà phê từ vùng đất Hàm Rồng - Gia Lai, cà phê hòa tan L\'amant Espresso mang tới mùi thơm dịu nhẹ nhưng vẫn giữ nguyên hương vị đầm và mạnh của cà phê / With a ideal essence of coffee beans from Ham Rong Mountain - Gia Lai, L\'amant espresso offers a gentle aroma, a strong and full body taste like a masterpiece of Italian espresso. L\'amant Espresso - A masterpiece that is reserved for the coffee lovers.', 20, 57000, 78000, 1, '2022-11-21 04:33:00'),
('LIBERICA', 'COLD', 'NCC4', 'Liberica', 'uploads/product/20221121161648-Screenshot2022-11-21231632.jpg', 'Hạt cà phê Liberica mang trong nó hương thơm ngọt nồng của trái mít mà không thể lẫn vào đâu được. Thưởng thức Liberica được rang bởi Flusso, ngoài hương mít ra bạn sẽ tìm thấy những điểm thú vị khác. Cà phê có body juicy và acid thấp trên nền vị ngọt và ngậy như bơ bám rất lâu trên vòm họng cho bạn một trải nghiệm vô cùng độc đáo khi thưởng thức loại cà phê này.', 20, 94000, 102000, 1, '2022-11-21 04:16:48'),
('MOKA01', 'PHIN', 'NCC3', 'Cà Phê Moka Blend', 'uploads/product/20221121165222-c7820185f3dbd0-cphmokablendfinnhm.png', 'Cà phê Moka Blend là sự kết hợp của Robusta, Moka, Culi và Cherry tạo ra hương vị cà phê có một không hai gây ấn tượng từ mùi hương gợi cảm đến vị đắng dễ chịu và dư vị tinh tế.', 25, 140000, 168000, 1, '2022-11-22 18:09:44'),
('MOKA02', 'PHIN', 'NCC4', 'Cà Phê Moka', 'uploads/product/20221121165324-63067346c5f6c5-cphmokafinnhm.png', 'Cà phê Moka thuộc dòng sản phẩm của Arabica, hạt có hình dáng thon dài và đường rãnh lượn sóng ở giữa hạt. Cà phê Moka có hương thơm nhẹ nhàng quyến rũ rất đặc trưng, vị từ chua chuyển sang hậu đắng rất đặc biệt. Khi pha cà phê có màu nâu nhạt sánh. Cà phê Moka sẽ là lựa chọn tuyệt vời cho những ai yêu thích cà phê sữa.', 20, 84000, 120000, 1, '2022-11-21 04:53:24'),
('NGCHAT01', 'NGCHAT', 'NCC4', 'Cà phê nguyên chất Hạt Thượng Hạng 1', 'uploads/product/20221121170401-1C6A6738-640x941.jpg', 'Cà phê Hạt Thượng Hạng 1 Nguyên Chất sạch 100% đặc biệt có vị đắng đậm đà, mùi hương thơm nhẹ, cafein vừa, chát, hậu vị ngọt.', 20, 235000, 269000, 1, '2022-11-21 05:04:01'),
('NGCHAT02', 'NGCHAT', 'NCC4', 'Cà phê nguyên chất Xay Thượng Hạng 2', 'uploads/product/20221121170506-1C6A6761-640x960.jpg', 'Bột cà phê Thượng Hạng 2 Nguyên Chất sạch 100% đặc biệt có vị đắng đậm đà, mùi hương thơm nhẹ, cafein vừa, chát, hậu vị ngọt.', 20, 275000, 319000, 1, '2022-11-21 05:05:06'),
('PREBLEND', 'ESPRESS', 'NCC3', 'Espresso Premium Blend', 'uploads/product/20221121163104-Screenshot2022-11-21233032.jpg', 'Espresso Premium là sự kết hợp 50:50 giữa hạt robusta honey và arabica washed espresso. Đúng như tên gọi, chúng tôi muốn có một blend phù hợp dành cho espresso. Cà phê có hương vị cân bằng, xoay quanh các tông vị chủ đạo là caramel và chocolate với một body đủ đậm để thể hiện tốt nhất những hương vị này. Giá trị acid tốt giúp cho espresso premium có tất cả những hương vị mà bạn muốn có trong một shot espresso đậm đà theo cách cân bằng nhất.', 20, 45000, 64000, 1, '2022-11-21 04:31:04'),
('ROB01', 'ROB', 'NCC5', 'Cà phê nguyên chất Hạt ROBUSTA', 'uploads/product/20221121170910-1C6A6754-640x960.jpg', 'Cà Phê Hạt Robusta Nguyên Chất sạch 100% đặc biệt có vị đắng đậm đà, mùi hương thơm nhẹ, cafein vừa, chát, hậu vị ngọt.', 20, 120000, 159000, 1, '2022-11-21 05:09:10'),
('ROYAL', 'PHIN', 'NCC2', 'Cà Phê Royal Special', 'uploads/product/20221121165435-c6bddc932220af-cphroyalspecialfinnhm.png', 'Cà phê Royal Special là sự kết hợp hoàn hảo giữa Moka, Robusta và Culi theo một tỉ lệ nhất định tạo nên một sản phẩm hội tụ cả sắc, hương và vị. Thưởng thức từng ngụm cà phê là cảm nhận dư vị tinh tế, sắc đen óng ánh sang trọng và vị đắng, chát lắng đọng.', 20, 79000, 110000, 1, '2022-11-21 04:54:35'),
('SUMMERVIBE', 'COLD', 'NCC4', 'Summer Vibe', 'uploads/product/20221121161535-1.jpg', 'Đem cả mùa hè của vùng nhiệt đới đến với bạn - Summer Vibe là sản phẩm được vô cùng yêu thích bởi các khách hàng của Flusso. Mang cả mùi thơm lẫn hương vị nồng nàn của các loại trái cây nhiệt đới như dứa, xoài và chanh dây, Summer Vibe thực sự ngọt lịm và tươi mát từ đầu cho tới cuối. Thưởng thức Summer Vibe giống như bạn đang uống cả mùa hè của xứ nhiệt đới vậy.', 20, 100000, 110000, 1, '2022-11-21 04:15:35'),
('VALENTINA', 'COLD', 'NCC2', 'Panama Boquete Valentina', 'uploads/product/20221121161910-Screenshot2022-11-21231758.jpg', 'Điểm đặc biệt nhất của loại cà phê này có thể được diễn tả là: \"nó có sự cân bằng hoàn hảo\". Có thể bạn đã từng thưởng thức những loại cà phê có hương trái cây thơm ngọt ngào cùng tông vị chua ngọt nổi bật; hoặc là những loại cà phê có tông caramel, chocolate mạnh mẽ với body dày? Vậy thì nếu một loại cà phê mang cả 2 tông vị đó thì sao? Panama Valentina có hương thơm ngọt ngào của mật ong, bị chua nhẹ nhàng của cam và sự mạnh mẽ của ca cao kết hợp cùng vị ngậy của hạt nướng.', 20, 115000, 130000, 1, '2022-11-21 04:19:58');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `MaQuyen` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `auth_token` text DEFAULT NULL,
  `TrangThai` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `MaQuyen`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `auth_token`, `TrangThai`) VALUES
(1, 'NV', 'null', '2022-11-20 07:29:44', 'null', '', '2022-11-20 07:29:44', '2022-11-20 08:21:26', '', 0),
(2, 'AD', 'minhduc140401@gmail.com', '2022-11-20 08:18:25', '$2y$10$Dl1in/SB1wstELI/D.UDouiGjjBpyIO4vU43OIaSuel1WhKwgUTIK', 'SEAQ26lxyz', '2022-11-20 08:18:25', '2022-11-23 00:15:46', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYXBpL3VzZXIvbG9naW4iLCJpYXQiOjE2NjkxODc3NDYsImV4cCI6MTY2OTE5MTM0NiwibmJmIjoxNjY5MTg3NzQ2LCJqdGkiOiJQNlBaNmRFczIxOWZhd3oxIiwic3ViIjoiMiIsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.xJYiL-qvOZT1PnUXHCxB75dlLDFQJ2uicXfmaX7IPE8', 1),
(7, 'QL', 'Camduyen20012@gmail.com', NULL, '$2y$10$tEJM42VHNLtWUABsA6vL5et919FMns6uwAibtTgEfiKFIPBfbErGG', 'KpP8a9rpjA', '2022-11-21 01:15:30', '2022-11-21 13:16:10', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYXBpL3VzZXIvbG9naW4iLCJpYXQiOjE2NjkwNjE3NzAsImV4cCI6MTY2OTA2NTM3MCwibmJmIjoxNjY5MDYxNzcwLCJqdGkiOiI4elh5OFlLdkNPR0RyT2tBIiwic3ViIjoiNyIsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.fogmE83F0pSLCowZ_ZMq9zOmVSRrEGXnpZf3jGhPjAw', 1);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chi_tiet_hoa_don`
--
ALTER TABLE `chi_tiet_hoa_don`
  ADD KEY `MaHD` (`MaHD`),
  ADD KEY `MaSP` (`MaSP`);

--
-- Chỉ mục cho bảng `chi_tiet_phieu_nhap`
--
ALTER TABLE `chi_tiet_phieu_nhap`
  ADD KEY `MaPNH` (`MaPNH`),
  ADD KEY `MaSP` (`MaSP`);

--
-- Chỉ mục cho bảng `chi_tiet_quyen`
--
ALTER TABLE `chi_tiet_quyen`
  ADD KEY `MaChucNang` (`MaChucNang`),
  ADD KEY `MaQuyen` (`MaQuyen`);

--
-- Chỉ mục cho bảng `chuc_nang`
--
ALTER TABLE `chuc_nang`
  ADD PRIMARY KEY (`MaChucNang`);

--
-- Chỉ mục cho bảng `danh_gia_san_pham`
--
ALTER TABLE `danh_gia_san_pham`
  ADD PRIMARY KEY (`MaBinhLuan`),
  ADD KEY `MaSP` (`MaSP`),
  ADD KEY `MaTK` (`MaTK`);

--
-- Chỉ mục cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Chỉ mục cho bảng `hoa_don`
--
ALTER TABLE `hoa_don`
  ADD PRIMARY KEY (`MaHD`),
  ADD KEY `MaKH` (`MaKH`),
  ADD KEY `MaNV` (`MaNV`);

--
-- Chỉ mục cho bảng `khach_hang`
--
ALTER TABLE `khach_hang`
  ADD PRIMARY KEY (`MaKH`),
  ADD KEY `id` (`MaTK`);

--
-- Chỉ mục cho bảng `loai_sp`
--
ALTER TABLE `loai_sp`
  ADD PRIMARY KEY (`MaLoaiSP`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD PRIMARY KEY (`MaNV`),
  ADD KEY `MaTK` (`MaTK`);

--
-- Chỉ mục cho bảng `nha_cung_cap`
--
ALTER TABLE `nha_cung_cap`
  ADD PRIMARY KEY (`MaNCC`);

--
-- Chỉ mục cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `password_resets_email_index` (`email`);

--
-- Chỉ mục cho bảng `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Chỉ mục cho bảng `phieu_nhap_hang`
--
ALTER TABLE `phieu_nhap_hang`
  ADD PRIMARY KEY (`MaPNH`),
  ADD KEY `MaNV` (`MaNV`),
  ADD KEY `MaNCC` (`MaNCC`);

--
-- Chỉ mục cho bảng `quyen_tai_khoan`
--
ALTER TABLE `quyen_tai_khoan`
  ADD PRIMARY KEY (`MaQuyen`);

--
-- Chỉ mục cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD PRIMARY KEY (`MaSP`),
  ADD KEY `MaLoaiSP` (`MaLoaiSP`),
  ADD KEY `MaNCC` (`MaNCC`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `MaQuyen` (`MaQuyen`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `chi_tiet_hoa_don`
--
ALTER TABLE `chi_tiet_hoa_don`
  ADD CONSTRAINT `chi_tiet_hoa_don_ibfk_1` FOREIGN KEY (`MaHD`) REFERENCES `hoa_don` (`MaHD`),
  ADD CONSTRAINT `chi_tiet_hoa_don_ibfk_2` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`);

--
-- Các ràng buộc cho bảng `chi_tiet_phieu_nhap`
--
ALTER TABLE `chi_tiet_phieu_nhap`
  ADD CONSTRAINT `chi_tiet_phieu_nhap_ibfk_1` FOREIGN KEY (`MaPNH`) REFERENCES `phieu_nhap_hang` (`MaPNH`),
  ADD CONSTRAINT `chi_tiet_phieu_nhap_ibfk_2` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`);

--
-- Các ràng buộc cho bảng `chi_tiet_quyen`
--
ALTER TABLE `chi_tiet_quyen`
  ADD CONSTRAINT `chi_tiet_quyen_ibfk_1` FOREIGN KEY (`MaChucNang`) REFERENCES `chuc_nang` (`MaChucNang`),
  ADD CONSTRAINT `chi_tiet_quyen_ibfk_2` FOREIGN KEY (`MaQuyen`) REFERENCES `quyen_tai_khoan` (`MaQuyen`);

--
-- Các ràng buộc cho bảng `danh_gia_san_pham`
--
ALTER TABLE `danh_gia_san_pham`
  ADD CONSTRAINT `danh_gia_san_pham_ibfk_2` FOREIGN KEY (`MaSP`) REFERENCES `san_pham` (`MaSP`),
  ADD CONSTRAINT `danh_gia_san_pham_ibfk_3` FOREIGN KEY (`MaTK`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `hoa_don`
--
ALTER TABLE `hoa_don`
  ADD CONSTRAINT `hoa_don_ibfk_1` FOREIGN KEY (`MaKH`) REFERENCES `khach_hang` (`MaKH`),
  ADD CONSTRAINT `hoa_don_ibfk_2` FOREIGN KEY (`MaNV`) REFERENCES `nhan_vien` (`MaNV`);

--
-- Các ràng buộc cho bảng `khach_hang`
--
ALTER TABLE `khach_hang`
  ADD CONSTRAINT `khach_hang_ibfk_1` FOREIGN KEY (`MaTK`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD CONSTRAINT `nhan_vien_ibfk_1` FOREIGN KEY (`MaTK`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `phieu_nhap_hang`
--
ALTER TABLE `phieu_nhap_hang`
  ADD CONSTRAINT `phieu_nhap_hang_ibfk_1` FOREIGN KEY (`MaNV`) REFERENCES `nhan_vien` (`MaNV`),
  ADD CONSTRAINT `phieu_nhap_hang_ibfk_2` FOREIGN KEY (`MaNCC`) REFERENCES `nha_cung_cap` (`MaNCC`);

--
-- Các ràng buộc cho bảng `san_pham`
--
ALTER TABLE `san_pham`
  ADD CONSTRAINT `san_pham_ibfk_1` FOREIGN KEY (`MaLoaiSP`) REFERENCES `loai_sp` (`MaLoaiSP`),
  ADD CONSTRAINT `san_pham_ibfk_2` FOREIGN KEY (`MaNCC`) REFERENCES `nha_cung_cap` (`MaNCC`);

--
-- Các ràng buộc cho bảng `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`MaQuyen`) REFERENCES `quyen_tai_khoan` (`MaQuyen`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
